package com.alexqueudot.soundbuttons

import android.media.MediaPlayer
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.widget.Button
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), OnItemClickListener {

    var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //Get JSON String
        var jsonString = resources.openRawResource(R.raw.sounds).bufferedReader().use { it.readText() }


        //Create List
        var gson = Gson()
        val soundList = gson.fromJson(jsonString, SoundList::class.java)


        soundList.sounds?.let {
            Log.i("MainACtivity", "Sounds length: "+it.count())
            // Set Layout Manager
            soundsRecyclerview.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
            // Create Adapter
            var adapter = SoundsAdapter(it)
            adapter.onSoundClickListener = this
            // Assign Adapter
            soundsRecyclerview.adapter = adapter

        }






//        button.setOnClickListener {
//            // Play first song
//            mediaPlayer?.release()
//
//            mediaPlayer = MediaPlayer.create(this, R.raw.rick)
//            mediaPlayer?.start() // no need to call prepare(); create() does that for you
//        }
//
//        button2.setOnClickListener {
//            // Play second song
//            mediaPlayer?.release()
//            mediaPlayer = MediaPlayer.create(this, R.raw.hog_rider)
//            mediaPlayer?.start() // no need to call prepare(); create() does that for you
//        }
    }

    override fun onItemClick(sound: SoundModel, position: Int) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer.create(this, resources.getIdentifier(sound.file,"raw", packageName))
        mediaPlayer?.start()
    }

    override fun onStop() {
        super.onStop()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
